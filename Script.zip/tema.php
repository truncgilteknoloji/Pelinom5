<?php include("bd.php"); ?>
<?php function start($c="") { ?>
<!DOCTYPE HTML>
<html lang="<?php wl(); ?>">
<head>
	<meta charset="UTF-8">
	<?php meta($c); ?>
	
</head>
<body>
<?php } ?>
<?php function finish() { ?>
</body>
</html>
<?php } ?>