<?php include("tema.php"); ?>
<?php start(); ?>
<?php pelinom5(); ?>
<?php finish(); ?>