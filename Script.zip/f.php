<?php 
if(getisset("dil")) {
	$dil = veri(get("dil"));
	$varmi = ksorgu("diller","WHERE kisa = $dil");
	if($varmi!=0) {
		oturum("dil",get("dil"));
	}
	
}
require("aa/lib/mail/include/class.php");
function mailGonder($mail,$konu,$mesaj){
$header = "";
$footer = "";
$mail_adresiniz	= "";
$mail_sifreniz	= "";
$gidecek_adres	= $mail;
$domain_adresi	= "";	//www olmadan yazınız

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

$mail = new PHPMail();
//$mail->Host       = "smtp.".$domain_adresi;
//$mail->SMTPAuth   = true;
//$mail->Username   = $mail_adresiniz;
//$mail->Password   = $mail_sifreniz;
//$mail->IsSMTP();
$mail->IsHTML(true);
$mail->AddAddress($gidecek_adres);
$mail->From       = $mail_adresiniz;
$mail->FromName   = "";
$mail->Subject    = $konu;
$mail->Body       = $header . $mesaj . $footer;
$mail->AltBody    = "";
	if(!$mail->Send()) {
		return $header . $mesaj . $footer;
	} else {
		return $header . $mesaj . $footer;
	}
}
 ?>
 <?php function cd($slug,$type="*.jpg") { //content directory
	global $depo; //elfinder depo
	$c = c($slug);
	$dir = $c['alt_resim'];
	$dir = "$depo/$dir/";
	return glob($dir.$type, GLOB_BRACE);
 } ?>
 <?php function c($slug) {
	 return kd(content($slug));
 } ?>
 <?php function ci($cid,$w=1920) { //content image
	 $c = kd(content_admin($cid));
	 e("r.php?w=$w&p=file/{$c['pic']}");
 } ?>
 <?php function cir($cid,$w=1920) { //content image
	 $c = kd(content_admin($cid));
	 return "r.php?w=$w&p=file/{$c['pic']}";
 } ?>
 <?php function cir2($cid) { //content image
	 $varmi = content_admin($cid);
	 if($varmi==0) {
		 dEkle("content",array(
			"slug" => $cid,
			"title" => $cid,
		 ));
	 }
	 $c = kd(content_admin($cid));
	 return "file/{$c['pic']}";
 } ?>
 <?php function ct($cid) { //content title
	 $c = kd(content_admin($cid));
	 e2($c['title']);
 } ?>
 <?php function cs($cid) { //content slug
	 $c = kd(content_admin($cid));
	 e($c['slug']);
 } ?>
 <?php function url($c=array()) {
	 e($c['slug'] .".html");
 }  ?>
 <?php function meta($c=array()) {
	 if(isset($c['slug'])) {
		 $link = "/{$c['slug']}.html";
		 $title=$c['title'];
		 $content = kelime(strip_tags($c['html']),20);
		 if($c['pic']!="") {
			$img = "/file/" . $c['pic'] ;
			
		 } else {
			$img = "/" . cir2("og_image") ;
			
		 }
		 $kelime = cokr($c['slug'],"Anahtar Kelimeler");
		 if($kelime!="") {
			 $keywords = $kelime;
		 } else {
			 $keywords = set("Anahtar Kelimeler",1);
		 }
	 } else {
		 $link = "";
		 $img = "/" . cir2("og_image") ;
		 $title=set("Başlık",1);
		 $content = set("Açıklama",1);
		 $keywords = set("Anahtar Kelimeler",1);
	 }
	 ?>
	 <title><?php if(isset($c['title'])) e($c['title']); else set("Başlık"); ?></title>

		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="<?php e($content); ?>">
		<meta name="keywords" content="<?php e($keywords) ?>" />
		<link rel="shortcut icon" type="image/png" href="<?php e(cir2("favicon")) ?>" />
		<meta name="author" content="<?php set("url") ?>">
		<!-- Twitter Card data -->
		<meta name="twitter:card" content="summary">
		<meta name="twitter:title" content="<?php e($title); ?>">
		<meta name="twitter:description" content="<?php e($content) ?>">
		<meta name="twitter:creator" content="@truncgilT">
		<meta name="twitter:image" content="<?php set("url"); ?><?php e($img) ?>">
		<meta property="og:image:type" content="image/jpeg" /> 
		<meta property="og:image:width" content="400" /> 
		<meta property="og:image:height" content="300" />
		<!-- Open Graph data -->
		<meta property="og:title" content="<?php e($title); ?>" />
		<meta property="og:type" content="article" />
		<meta property="og:url" content="<?php set("url"); ?><?php e($link) ?>" />
		<meta property="og:image" content="<?php set("url"); ?><?php e($img) ?>" />
		<meta property="og:description" content="<?php e($content) ?>" /> 
		<meta property="og:site_name" content="<?php e($title); ?>" />
		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="aa/flag/css/flag-icon.min.css" />
	 <?php
 } ?>
 <?php 
function cl_http($url) {
  $U = explode(' ',$url);

  $W =array();
  foreach ($U as $k => $u) {
if (stristr($u,'http') || (count(explode('.',$u)) > 1)) {
  unset($U[$k]);
  return cl_http( implode(' ',$U));
}
}
  return implode(' ',$U);
}
 ?>
 <?php function e2($deger) {
	global $_SESSION;
	oturumAc();
	if(oturumisset("dil")) { //dil seçimi yapılmışsa
		$dil = veri(oturum("dil")); // dil hangisi
		$i = veri($deger);
		//verilen ifade ilgili dilde var mı 
		$translate = ksorgu("translate","WHERE i=$i AND dil = $dil");
		if($translate!=0) {
			$t = kd($translate);
			//print_r($t);
			if($t['t']!="") { //verilen ifadenin çevirisi yapılmış mı?
				echo $t['t'];
			} else {	
				echo $deger;
			}
		} else { //verilen ifade yoksa çevirisini dil sayısına göre oluştur.
			$diller = ksorgu("diller");
			while($d=kd($diller)) {
				$dil = veri($d['kisa']);
				
				$varmi = ksorgu("translate","WHERE i=$i AND dil = $dil");
				//print_r($varmi);
				if($varmi==0) {
					//$deger = cl_http($deger);
					if(trim($deger)!="") {
						if(isHTML($deger)) {
							//$deger = strip_tags($deger);
						}
						dEkle("translate",array(
							"dil" => $d['kisa'],
							"i" => "$deger"
						));
					}
				}
			}
			echo $deger;
		}
	} else {
		echo $deger;
	}
} ?>
<?php function r($img,$size="1024",$dir="file/") { 
	e("r.php?w=$size&p=$dir/$img");
}
 ?>

<?php function r2($img,$size="1024",$dir="file/") { 
	e("r.php?h=$size&p=$dir/$img");
}
 ?>
<?php function ll($s="",$f=""){
	$diller = ksorgu("diller","ORDER BY id ASC");
	e("<ul class='diller $s'>");
		e("<li><a href='?dil=tr' class='$f'><i class='flag-icon flag-icon-tr'></i></a></li>");
	while($d = kd($diller)) {
		e("<li><a href='?dil={$d['kisa']}' class='$f'><i class='flag-icon flag-icon-{$d['kisa']}'></i></a></li>");
	}
	e("</ul>");
	
} ?>
 <?php function wl($varsayilan="tr") {  //what language
	 oturumAc();
	 global $_SESSION;
	 if(oturumisset("dil")) {
		 e(oturum("dil"));
	 } else {
		 e($varsayilan);
		 oturum("dil",$varsayilan);
	 }
	 
 } ?>
<?php 
function ara($bas, $son, $icerik)
{
    @preg_match_all('/' . preg_quote($bas, '/') .
    '(.*?)'. preg_quote($son, '/').'/i', $icerik, $m);
    return $m;
}  
function ara2($icerik)
{
   preg_match_all( '/{{(.+?)\}}/', $icerik, $blocks );
    return $blocks;
}  
 ?>
 <?php 
function isHTML($string){
 return $string != strip_tags($string) ? true:false;
}
 ?>
 <?php function set($alan,$return="") {
	 $varmi =ksorgu("other","WHERE alan = '$alan' AND cid = 'common_settings'");
	 if($varmi!=0) {
	 $ayar = kd($varmi);
	// print_r($ayar);
	 if($return=="") {
	//	 e($ayar['deger']);
		 e2($ayar['deger']);
	 } else {
		 return $ayar['deger'];
	 } } else {
		 dEkle("other",array(
			"alan" => $alan,
			"cid" => "common_settings"
		 ));
	 } 
	 
	 
 } ?>
 <?php function cok($id,$key) { //content other key echo
	 $kim = kd(ksorgu("other","WHERE cid = '$id' AND alan='$key'"));
	 e($kim['deger']);
 } ?>
 <?php function cok2($id,$key) { //content other key echo
	 $kim = kd(ksorgu("other","WHERE cid = '$id' AND alan='$key'"));
	 e2($kim['deger']);
 } ?>
 <?php function cokr($id,$key) { //content other key return
	 $kim = kd(ksorgu("other","WHERE cid = '$id' AND alan='$key'"));
	 return $kim['deger'];
 } ?>
 <?php function cju($id) { //content json update
	$kim = kd(ksorgu("other","WHERE id = $id"));
	e($id);
	print_r($kim);
	$veri = ksorgu("other","WHERE cid = '{$kim['cid']}'");//ilgili şahsın verilerini al
	$json =array();
	$k=0;
	while($v = kd($veri)) { //verileri bir dizide toparla ve 
		$json[$k][$v['alan']] = $v['alan'];
		$json[$k][$v['deger']] = $v['deger'];
		$k++;
	}
	print_r($json);
	$json = json_encode($json);
	dGuncelle("content",array( // ve content json a yaz
	"json" => $json
	),"slug = '{$kim['cid']}'");
 } ?>
 <?php function tv($ifade,$dil) {
	 if(trim($ifade)!="") {
	 $i = veri($ifade);
	 $varmi = ksorgu("translate","WHERE i = $i AND dil = '$dil'");
	 if($varmi!=0) { //buldun mu
		$trans = kd($varmi);
		 return $trans['t'];
	 } else { 
		 $ifade = kelime($ifade,5); //bulamadıysan cümleyi kısalt öyle bir ara
		 $i = veri("%$ifade%");
		// e($i);
		 $varmi = ksorgu("translate","WHERE i LIKE $i AND dil = '$dil'");
		 if($varmi!=0) { //bulduysan çıktıla
			 return $trans['t'];
		 } 
	 }
	 }
	
 } ?>
 <?php function ti($ifade,$dil) {
	 $i = veri($ifade);
	 $trans = kd(ksorgu("translate","WHERE i = $i AND dil = '$dil'"));
	 return $trans['id'];
 } ?>
<?php 
function google($title,$start=0) {
	if($title!="") {
		$title = urlencode($title);
		$json = file_get_contents("http://ajax.googleapis.com/ajax/services/search/images?v=1.0&q=$title&start=$start");
		$obj = json_decode($json);
		return $obj->responseData->results;
	}
}
 ?>
 <?php function bbaslik($title,$detay="") {
	 ?>
<div class="row firstRow">
	<div class="col-lg-9  col-md-8  col-sm-7">
		<div class="firstRowHeader">
			<h5><?php e($title) ?></h5>
		</div>
		<p><?php e($detay) ?></p>
	</div>
	<div class="col-lg-3   col-md-4  col-sm-5">
		
	</div>
</div>	 
	 <?php
 } ?>
<?php function layerslider($slug) {
	?>
	<?php $slider=kd(content($slug)); ?>
	<div class="ls-wp-container layerslider noback" style="<?php e($slider['style']); ?>">
	<?php $slides = contents($slug); ?>
	<?php while($s = kd($slides)) { ?>
		<?php if($s['code']!="") { //code bilgisine yığın layerslider bilgisi girilmesi için
			e($s['code']);
		} else { ?>
			<div class="ls-slide" data-ls="<?php e($s['datals']) ?>">
				<?php if($s['pic']!="") { ?>
					<img src="r.php?w=1200&p=file/<?php e($s['pic']) ?>" class="ls-bg" alt="" />
				<?php } ?>
				<?php $layers = contents($s['slug']); ?>
				<?php while($l = kd($layers)) { ?>
					<div class="ls-l" style="<?php e($l['style']) ?>" alt="<?php e($l['alt']) ?>" data-ls="<?php e($l['datals']) ?>">
						<?php if($l['pic']) {
							?>
							<img src="file/<?php e($l['pic']) ?>" alt="" />
							<?php
						} ?>
						<?php e($l['html']); ?>
					</div>
				<?php } ?>
			</div>
		<?php } ?>
	<?php } ?>
	</div>
	<?php
	
} ?>
<?php function layerslider2($slug) {
	?>
	<?php $slider=kd(content($slug)); ?>
	<div class="ls-wp-container layerslider noback" style="<?php e($slider['style']); ?>">
	<?php $slides = contents($slug); ?>
	<?php while($s = kd($slides)) { ?>
		<?php if($s['code']!="") { //code bilgisine yığın layerslider bilgisi girilmesi için
			e($s['code']);
		} else { ?>
			<div class="ls-slide" data-ls="<?php e($s['datals']) ?>">
				<?php if($s['pic']!="") { ?>
					<img src="../r.php?w=1920&p=file/<?php e($s['pic']) ?>" class="ls-bg" alt="" />
				<?php } ?>
				<?php $layers = contents($s['slug']); ?>
				<?php while($l = kd($layers)) { ?>
					<div class="ls-l" style="<?php e($l['style']) ?>" alt="<?php e($l['alt']) ?>" data-ls="<?php e($l['datals']) ?>">
						<?php if($l['pic']) {
							?>
							<img src="../file/<?php e($l['pic']) ?>" alt="" />
							<?php
						} ?>
						<?php e($l['html']); ?>
					</div>
				<?php } ?>
			</div>
		<?php } ?>
	<?php } ?>
	</div>
	<?php
	
} ?>

<?php function bg($url) {
	echo "<style type='text/css'>
	content{
		background:url($url) !important;
		background-size: cover !important;
	}
		</style>";
} ?>
<?php function bg2($url) {
	echo "<style type='text/css'>
	.ui-page { 
		background:url($url) !important;
		background-size: cover !important;
	}
		</style>";
} ?>
<?php function title($isim,$kat="") {
	$isim2 = explode(".",$isim);
	return "{$isim2[0]}";
} ?>

<?php function galeri2($isim,$kat) {
	$isim = veri($isim);
	$galeri = kd(ksorgu("galerikategori","WHERE isim=$isim"));
	$galericerik = ksorgu("galeriicerik","WHERE gid='{$galeri['id']}' ORDER BY sira ASC");
	//e("<div class='caro'>");
	
	while($g = kd($galericerik)) {
		$title="";// title($g['url'],$kat);
		e("<a  title='$title' href='r.php?p=pfi-galeri-icerik/{$g['url']}&w=1024' data-lightbox='galeri' class='urun'>
				<img src='r.php?p=pfi-galeri-icerik/{$g['url']}&h=350' />
				<h2>$title</h2>
			</a>");
	}
	//e("</div>");
	
} ?>
<?php function galericaro($isim) {
	$isim = veri($isim);
	$galeri = kd(ksorgu("galerikategori","WHERE isim=$isim"));
	$galericerik = ksorgu("galeriicerik","WHERE gid='{$galeri['id']}' ORDER BY sira ASC");
	e("<div class='caro'>");
	while($g = kd($galericerik)) {
		$title="";// title($g['url'],$kat);
		e("
				<img src='../r.php?p=pfi-galeri-icerik/{$g['url']}&h=550' style='width:80%;max-width:550px;margin:0 auto;display:block;' />
		 ");
	}
	e("</div>");
	
} ?>

<?php function galeri3($isim) {
	$isim = veri($isim);
	$galeri = kd(ksorgu("galerikategori","WHERE isim=$isim"));
	$galericerik = ksorgu("galeriicerik","WHERE gid='{$galeri['id']}' ORDER BY sira ASC");
	e("<div class=\"galeri\">");
	while($g = kd($galericerik)) {
		$title= title($g['url'],$kat);
		e("<a title='$title' href='#{$g['id']}' data-rel='popup' data-position-to='window' data-transition='fade' class='ui-btn ui-btn-inline' data-lightbox='galeri'><img src='../r.php?p=pfi-galeri-icerik/{$g['url']}&w=141&h=120' /></a>");
		e("
		<div data-role='popup'  id='{$g['id']}' data-overlay-theme='b' data-theme='b' data-corners='false'>
		    <a href='#' data-rel='back' class='ui-btn ui-corner-all ui-shadow ui-btn-a ui-icon-delete ui-btn-icon-notext ui-btn-right'>Kapat</a>
			<a href='../pfi-galeri-icerik/{$g['url']}' data-ajax='false'><img  class='popphoto' src='../r.php?p=pfi-galeri-icerik/{$g['url']}&h=512' style='max-height:512px;margin:0 auto;display:block' ></a>
			
		</div>
		");
	}
	e("</div>");
	
} ?>
<?php 
function tkid($id,$static=""){
if($static!="") :
	static $toplam;
else :
	$toplam = "";
endif;
$sorgu = ksorgu("urun_kategori","WHERE ust=$id");
	if($sorgu!=0) :
	while($s = kd($sorgu)) {
		$toplam .= $s['id'] . ",";
		tkid($s['id']);
	}
	endif;
	$sonuc = substr($toplam,0,strlen($toplam)-1);
	if($sonuc!="") {
		return $id . "," . $sonuc;
	} else {
		return $id;
	}
} ?>
<?php 
$breadcrumb="";
function breadcrumb($id) {
global $breadcrumb;
	$kat = kd(ksorgu("content","WHERE slug=$id"));
	$isim = $kat['title'];
	$slug = $kat['slug'];
		$breadcrumb =  "<li><a href='?i=sayfa&s=$slug'>$isim</a></li>" . $breadcrumb;
	if($kat['kid']!="") {
		breadcrumb($kat['kid']);
	} else {
		$breadcrumb = "<li><a href='urunler.php'>Ürünler</a></li>" . $breadcrumb;
	}
	return $breadcrumb;
}
 ?>

<?php function content($slug,$where="") {
	$content = ksorgu("content","WHERE y=1 AND slug='$slug' $where");
	return $content;
} ?>
<?php function content_admin($slug,$where="") {
	$content = ksorgu("content","WHERE slug='$slug' $where");
	return $content;
} ?>
<?php function content_id($id,$where="") {
	$content = ksorgu("content","WHERE y=1 AND id='$id' $where");
	return $content;
} ?>
<?php function contents($slug="",$where="",$limit="0,100") {
	if($slug=="") {
		$content = ksorgu("content","WHERE y=1 AND kid IS NULL $where ORDER BY s ASC LIMIT $limit");
	} else {
		$content = ksorgu("content","WHERE y=1 AND kid='$slug' $where ORDER BY s ASC LIMIT $limit");
	}
	
	return $content;
} ?>
<?php function contents_admin($slug="",$where="",$limit="0,100") {
	if($slug=="") {
		$content = ksorgu("content","WHERE kid IS NULL $where ORDER BY s ASC LIMIT $limit");
	} else {
		$content = ksorgu("content","WHERE kid='$slug' $where ORDER BY s ASC LIMIT $limit");
	}
	
	return $content;
} ?>
<?php function contents2($slug,$where="",$limit="0,100") {
	$content = ksorgu("content","WHERE y=1 AND kid IN ($slug) $where ORDER BY s ASC LIMIT $limit");
	return $content;
} ?>

<?php function anamenu($slug,$alt=false){
	global $uzanti;
	$content = contents($slug);
	if($content!=0) {
		while($c = kd($content)) {
			e("<li><a href='{$c['slug']}.$uzanti'>{$c['title']}</a>");
				if($alt==true) {
					e("<ul>").anamenu($c['slug'],true).e("</ul>");
				}
			e("</li>");
		}
	}
} ?>
<?php function col2($boyut="col-md-3",$title="") { ?>
<div class="<?php e($boyut) ?>">
	<div class="panel panel-default drag">
	<?php if($title!="") { ?>
		<div class="panel-heading clearfix ">
			<div class="panel-heading-title pull-left">
				<h6><?php e($title) ?></h6>
			</div>
		</div>
	<?php } ?>
	<div class="panel-body clearfix">
<?php } ?>
<?php function _col2() {
	?>
</div>
</div>		
</div>		
<?php
} ?>
<?php function selectDirList($secili="") {
	global $depo;
	$dir = new DirectoryIterator($depo);
		e("<option value='' selected>Dizin Yok</option>");

	foreach ($dir as $fileinfo) {
		if ($fileinfo->isDir() && !$fileinfo->isDot()) {
			$alt_dir = new DirectoryIterator($depo ."/" . $fileinfo->getFilename());
			e("<optgroup label='{$fileinfo->getFilename()}'>");
			$select ="";
			if($fileinfo->getFilename()==$secili) {
						$select ="selected";
					}
			echo "<option value='{$fileinfo->getFilename()}' $select>{$fileinfo->getFilename()} (Ana Dizin)</option>";
			foreach ($alt_dir as $fileinfo2) {
				if ($fileinfo2->isDir() && !$fileinfo2->isDot()) {
					$select ="";
					if("{$fileinfo->getFilename()}/{$fileinfo2->getFilename()}"==$secili) {
						$select ="selected";
					}
					echo "<option value='{$fileinfo->getFilename()}/{$fileinfo2->getFilename()}' $select>{$fileinfo->getFilename()}/{$fileinfo2->getFilename()}</option>";
				}
			
			}
			e("</optgroup>");
	}

	}

} ?>
<?php function yeniIcerikFormu($boyut = "col-md-6",$slug="") {
	?>
<?php col2($boyut,"Bu Alana Yeni İçerik Ekle"); ?>
				<form action="?ekle" method="post" enctype="multipart/form-data" >
					<div class="row">
						<div class="col-md-12">
							<div class="col-md-5">
								<label for="">Başlık</label>
								<input type="text" name="title" id="title" required class="form-control" />
							</div>
							<div class="col-md-4">
								<label for="">URL</label>
								<input type="text" name="slug" id="slug" required class="form-control" />
							</div>
							<div class="col-md-3">
								<label for="">Kapak Resmi</label>
								<input type="file" name="pic" class="form-control" />
							</div>
							<div class="row">
								<div class="col-md-6">
									<label for="">Ek Dosyalar Dizini</label>
									<select name="alt_resim" id="" class="form-control">
									<?php 
										selectDirList();
									?>
									</select>
								</div>
								<div class="col-md-6">
									<label for="">Üst Kategori</label>
									<input type="text" name="kid" value="<?php e($slug) ?>" class="form-control" />
								</div>
							</div>
						</div>
						
					</div>												
					<div class="row">
						<div class="col-md-12">
							<label for="">İçerik</label>
							<textarea name="html" id="editor" class="ckeditor" cols="45" rows="5"></textarea>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 ">
							<button type="submit" href="#" class="btn btn-primary"><i class="fa fa-refresh"></i> Bilgileri Güncelle</button>
						</div>
						
					</div>
					</form>
					<?php _col2(); ?>
	<?php
} ?>
<?php function alert($icerik) {
	?>
	<div class="alert alert-primary" role="alert">
		<?php e($icerik) ?>
	</div>
	<?php
} ?>
<?php function pelinom5() {
	e('<div style="    background: #008DD2 url(aa/pelinom.png) center center no-repeat;
    line-height: 78px;
    height: 162px;
    margin: -10px;
    position: absolute;
    width: 100%;
    height: 100%;">
	</div>');
} ?>
<?php function col($boyut="col-md-3",$a = array()) {
	global $_GET;
	/*if(!isset($a['icon'])) {
		$a['icon'] ="pencil";
	}*/
	?>
<div class="<?php e($boyut) ?>" id="id-<?php e($a['id']) ?>" >
	<div class="panel panel-default drag" id="<?php e($a['id']) ?>" style="background:url(r.php?w=512&p=file/<?php e($a['pic']) ?>) 90% center no-repeat white;background-size: contain;">
		<div class="panel-heading clearfix ">
			<div class="panel-heading-title pull-left">
				<h6><a href="?i=sayfa&s=<?php e($a['slug']) ?>"><?php e2($a['title']) ?></a></h6>
			</div>
			<!--panel-heading-title-->
			<div class="panel-heading-buttons pull-right">
				<div class="bs-example">
					<p class="clearfix">
						<a ajax="#id-<?php e($a['id']) ?>" teyit="<?php e($a['title']) ?> içeriğini gerçekten silmek istediğinizden emin misiniz?" href="?sil=<?php e($a['id']) ?>" class="btn"> <i class="fa fa-times"></i></a>
						<a href="?cogalt=<?php e($a['slug']) ?>" teyit="<?php e($a['title']) ?> İçeriğini alt içerikleriyle beraber çoğaltmak istediğinizden emin misiniz?" class="btn"><i class="fa fa-files-o"></i></a>
				</p></div>
			</div>
			<!--panel-heading-buttons-->
		</div>
		<div class="panel-body clearfix" >
		<?php if(isset($a['pic'])) { ?>
			
		<?php } ?>
			<div class="amsterdamContent">
				<div class="amsterdamButtonPlaseholder">
					
				</div>

				<?php if($a['html']!="") { 
				//	e(kelime(strip_tags($a['html']),30));
				 } ?>
			</div>
			<div class="buttonWrapper">
				<button type="button" id="<?php e($a['id']) ?>" deger="<?php e($a['y']); ?>" class="yayin btn <?php if($a['y']==0) e("btn-danger"); else e("btn-success"); ?>  buttonsRoundedLarge float-button-light waves-effect waves-button waves-float waves-light"><i class="fa fa-wifi"></i></button>
			</div>
		</div>
	</div>
	<!--panel-body-->
</div>	
	<?php
} ?>
<?php 
$hiyerarsi="";
$k = 0;
function hiyerarsi($id) {
global $k;
global $hiyerarsi;
	$kat = kd(ksorgu("content","WHERE slug='$id'"));
	$isim = $kat['title'];
	$a = $kat['slug'];
	if($k==0) {
		$hiyerarsi =  "<li>$isim</li>" . $hiyerarsi;
	} else {
		$hiyerarsi =  "<li><a href='?i=sayfa&s=$a'>$isim</a></li>" . $hiyerarsi;
	}
		
	if($kat['kid']!="") {
		$k++;
		hiyerarsi($kat['kid']);
	}
	return "
		<ol class='breadcrumb'>
			<li><a href='admin'>Anasayfa</a></li>
			$hiyerarsi
		</ol>";
}
 ?>
<?php 
$hiyerarsi2="";
function hiyerarsi_web($id) {
global $hiyerarsi;
global $uzanti;
	$kat = kd(ksorgu("content","WHERE slug='$id'"));
	$isim = $kat['title'];
	$a = $kat['slug'];
	if($kat['kid']!="") {
		$hiyerarsi =  "<a class='dugme' href='$a.$uzanti'>$isim</a> " . $hiyerarsi;
	}
	if($kat['kid']!="") {
		hiyerarsi_web($kat['kid']);
	}
	return "<div class='butonset'>$hiyerarsi</div>";
}
 ?>
 <?php function katisset($ara,$slug) {
	 $sonuc = hiyerarsisade($slug);
	 if(strpos($sonuc,$ara)!==false) {
		 return 1;
	 } else {
		 return 0;
	 }
 }  ?>
 <?php 
$hiyerarsisade="";
function hiyerarsisade($id) {
global $hiyerarsisade;
	$kat = kd(ksorgu("content","WHERE slug='$id'"));
	$isim = $kat['title'];
	$a = $kat['slug'];
		$hiyerarsisade =  "$a, " . $hiyerarsisade;
	if($kat['kid']!="") {
		hiyerarsisade($kat['kid']);
	}
	return "$hiyerarsisade";
}
$altkat=array();
function altkat($id) {
global $altkat;
	$kat = ksorgu("content","WHERE kid='$id'");
	while($k = kd($kat)) {
		array_push($altkat,veri($k['slug']));
	}
	return implode($altkat,",");
}
 ?>
<?php 
$hiyerarsi3="";
function hiyerarsi_web2($id) {
global $hiyerarsi3;
global $uzanti;
	$kat = kd(ksorgu("content","WHERE slug='$id'"));
	$isim = $kat['title'];
	$a = $kat['slug'];
	if($kat['kid']!="") {
		$hiyerarsi3 =  "<a href='$a.$uzanti' class='ui-btn ui-btn-inline' data-theme='b'>$isim</a>" . $hiyerarsi3;
	}
	if($kat['kid']!="") {
		hiyerarsi_web2($kat['kid']);
	}
	return "<a href='index' class='ui-btn ui-btn-inline'><i class='fa fa-home'></i></a>$hiyerarsi3";
}
 ?>
<?php 
function postyukle($post,$dizin) {
	if($_FILES[$post]['name']!="") {
		$_POST[$post] = yukle($post,$dizin);
	}
}
function posttarih($post) {
	$_POST[$post] = simdi();
}
function zftr($d2){
 $d1 = date('Y-m-d H:i:s');
 
    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);
if ($d1-$d2<0) {
$ifade = "sonra";
} else {
$ifade = "önce";
 }
$once = " "; 
    if($d>=(60*60*24*365))    $sonuc  = $once . floor($d/(60*60*24*365)) . " yıl $ifade";
    else if($d>=(60*60*24*30))     $sonuc = $once . floor($d/(60*60*24*30)) . " ay $ifade";
    else if($d>=(60*60*24*7))  $sonuc  = $once . floor($d/(60*60*24*7)) . " hafta $ifade";
    else if($d>=(60*60*24))    $sonuc  = $once . floor($d/(60*60*24)) . " gün $ifade";
    else if($d>=(60*60))   $sonuc = $once . floor($d/(60*60)) . " saat $ifade";
    else if($d>=60) $sonuc  = $once . floor($d/60)  . " dakika $ifade";
	else $sonuc = "Az $ifade";
 
    return $sonuc;
}
function zfen($d2){
 $d1 = date('Y-m-d H:i:s');
 
    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);
if ($d1-$d2<0) {
$ifade = "left";
} else {
$ifade = "ago";
 }
$once = " "; 
    if($d>=(60*60*24*365))    $sonuc  = $once . floor($d/(60*60*24*365)) . " year $ifade";
    else if($d>=(60*60*24*30))     $sonuc = $once . floor($d/(60*60*24*30)) . " month $ifade";
    else if($d>=(60*60*24*7))  $sonuc  = $once . floor($d/(60*60*24*7)) . " week $ifade";
    else if($d>=(60*60*24))    $sonuc  = $once . floor($d/(60*60*24)) . " day $ifade";
    else if($d>=(60*60))   $sonuc = $once . floor($d/(60*60)) . " hour $ifade";
    else if($d>=60) $sonuc  = $once . floor($d/60)  . " minute $ifade";
	else $sonuc = "Few $ifade";
 
    return $sonuc;
}
function zfar($d2){
 $d1 = date('Y-m-d H:i:s');
 
    if(!is_int($d1)) $d1=strtotime($d1);
    if(!is_int($d2)) $d2=strtotime($d2);
    $d=abs($d1-$d2);
if ($d1-$d2<0) {
$ifade = "فيما بعد";
} else {
$ifade = "قبل";
 }
$once = " "; 
    if($d>=(60*60*24*365))    $sonuc  = $once . floor($d/(60*60*24*365)) . " عام $ifade";
    else if($d>=(60*60*24*30))     $sonuc = $once . floor($d/(60*60*24*30)) . " شهر $ifade";
    else if($d>=(60*60*24*7))  $sonuc  = $once . floor($d/(60*60*24*7)) . " أسبوع $ifade";
    else if($d>=(60*60*24))    $sonuc  = $once . floor($d/(60*60*24)) . " يوم $ifade";
    else if($d>=(60*60))   $sonuc = $once . floor($d/(60*60)) . " ساعة $ifade";
    else if($d>=60) $sonuc  = $once . floor($d/60)  . " دقيقة $ifade";
	else $sonuc = "القليل $ifade";
 
    return $sonuc;
}

?>
<?php function jd($d){
return json_decode($d['deger'],true);
} ?>
<?php function via($islem,$url="") { 
	global $via; 
	if($url==""){
		$adres =""; 
	}else {
		$adres = "&y=$url";
	} 
	echo $via.$islem.$adres; 
} ?>
