<?php 

izin("pFiUser","peyamFi","index.php"); 

if(isset($_GET['cikis']) && ($_GET['cikis']==1)) { //cikis isimli bir get değişkenin değeri 1 olması durumunda bütün oturum değişkenleri silinir. Bir ayak izi dahi bırakmaz 
				oturumSil("uid");
				oturumSil("pFiMail");
				oturumSil("pFiUser");
				oturumSil("pFi");
				oturumSil("Seviye");
				oturumSil("adi");
				oturumSil("soyadi");
				yonlendir("login");

}

/*
//her kullanıcının kendine ait bir dizini olmalı
$root = substr(kripto(oturum("uid") . "peyamFi"),0,15) . "/";
if (!file_exists("pfi-depo/" . $root)) {
mkdir("pfi-depo/" . $root);
}
//echo $root;
$dizin =  $_SERVER['SERVER_NAME'];
$site = $_SERVER['HTTP_HOST'];
//echo "http://" . $dizin . "/WEB/2012/GYSD/gysd/gysd/"  . $root;
*/
//kullanıcı değişkenleri
$kullanici = oturum("adi") . " " . oturum("soyadi");
$uid = oturum("uid");
$mail = oturum("pFiMail");
$seviye = oturum("Seviye2");

if($seviye=="Okuyucu") {
	yonlendir("login");
}
if($seviye=="Yazar") {
	yonlendir("login");
}

?>