<?php 
include("tema.php");
$c = c(get("id"));
start($c);
	switch(get("id")) {
			default:
			/// içerik kodları buraya
			break;
	}
	
finish();
?>

