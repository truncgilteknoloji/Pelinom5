/*  SELECT */	
$(document).ready(function() {
  $('select').niceSelect();
});
		
  