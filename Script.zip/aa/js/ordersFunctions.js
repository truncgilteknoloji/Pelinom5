/* Data Table*/
$(document).ready(function () {
	$('#example').DataTable();
	$('.minimal-checkbox-default').iCheck({
		checkboxClass: 'icheckbox_square-pink',
		increaseArea: '20%'
	});
});





       
